CREATE DATABASE EventManagementDB;
USE EventManagementDB;

CREATE TABLE events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    location VARCHAR(255),
    date DATE
);
DESCRIBE events;
INSERT INTO events (name, description, location, date)
VALUES
('Tech Meetup', 'A meetup for tech enthusiasts', 'New York', '2024-01-15'),
('Hackathon', 'A 24-hour coding competition', 'San Francisco', '2024-02-10'),
('Workshop', 'Python programming workshop', 'Chicago', '2024-03-05');
SELECT * FROM events;
CREATE TABLE attendees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL
);
CREATE TABLE tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    status ENUM('Pending', 'Completed') DEFAULT 'Pending',
    deadline DATE,
    event_id INT,
    attendee_id INT,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    FOREIGN KEY (attendee_id) REFERENCES attendees(id) ON DELETE SET NULL
);

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('Attendee', 'Event Manager') NOT NULL
);

DESCRIBE attendees;
DESCRIBE tasks;


