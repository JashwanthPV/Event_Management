from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)

# Configurations
app.secret_key = 'your_secret_key'
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'Jashwanth'
app.config['MYSQL_PASSWORD'] = 'Shreyas*3801'
app.config['MYSQL_DB'] = 'EventManagementDB'

# Initialize MySQL
mysql = MySQL(app)

# Example user data (you can replace this with the data in the database)
example_username = 'admin'
example_password = 'adminpassword'
hashed_password = generate_password_hash(example_password)

# Route for logging out
@app.route('/logout')
def logout():
    session.pop('username', None)
    session.pop('role', None)
    return redirect(url_for('login'))

@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # For testing purposes, you can check against the example credentials
        if username == example_username and check_password_hash(hashed_password, password):
            session['username'] = username
            session['role'] = 'Event Manager'  # You can modify this based on your logic
            return redirect(url_for('dashboard'))
        else:
            error = "Invalid Credentials"

    return render_template('login.html', error=error)

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        # Fetch events from the database
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM events")
        events = cur.fetchall()
        cur.close()
        return render_template('events.html', events=events)
    else:
        return redirect(url_for('login'))

# Event CRUD API
@app.route('/api/events', methods=['GET'])
def get_events():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM events")
    events = cur.fetchall()
    cur.close()
    return jsonify(events)

@app.route('/api/events', methods=['POST'])
def create_event():
    data = request.get_json()
    name = data['name']
    description = data['description']
    location = data['location']
    date = data['date']
    cur = mysql.connection.cursor()
    cur.execute("INSERT INTO events (name, description, location, date) VALUES (%s, %s, %s, %s)",
                (name, description, location, date))
    mysql.connection.commit()
    cur.close()
    return jsonify({"message": "Event created successfully"}), 201

@app.route('/api/events/<int:id>', methods=['PUT'])
def update_event(id):
    data = request.get_json()
    name = data['name']
    description = data['description']
    location = data['location']
    date = data['date']
    cur = mysql.connection.cursor()
    cur.execute("UPDATE events SET name=%s, description=%s, location=%s, date=%s WHERE id=%s",
                (name, description, location, date, id))
    mysql.connection.commit()
    cur.close()
    return jsonify({"message": "Event updated successfully"}), 200

@app.route('/api/events/<int:id>', methods=['DELETE'])
def delete_event(id):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM events WHERE id=%s", (id,))
    mysql.connection.commit()
    cur.close()
    return jsonify({"message": "Event deleted successfully"}), 200

# Attendee CRUD API
@app.route('/api/attendees', methods=['GET'])
def get_attendees():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM attendees")
    attendees = cur.fetchall()
    cur.close()
    return jsonify(attendees)

@app.route('/api/attendees', methods=['POST'])
def create_attendee():
    data = request.get_json()
    name = data['name']
    email = data['email']
    cur = mysql.connection.cursor()
    cur.execute("INSERT INTO attendees (name, email) VALUES (%s, %s)", (name, email))
    mysql.connection.commit()
    cur.close()
    return jsonify({"message": "Attendee added successfully"}), 201

@app.route('/api/attendees/<int:id>', methods=['DELETE'])
def delete_attendee(id):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM attendees WHERE id=%s", (id,))
    mysql.connection.commit()
    cur.close()
    return jsonify({"message": "Attendee deleted successfully"}), 200

# Task CRUD API
@app.route('/api/tasks', methods=['GET'])
def get_tasks():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM tasks")
    tasks = cur.fetchall()
    cur.close()
    return jsonify(tasks)

@app.route('/api/tasks', methods=['POST'])
def create_task():
    data = request.get_json()
    name = data['name']
    status = data['status']
    deadline = data['deadline']
    event_id = data['event_id']
    attendee_id = data['attendee_id']
    cur = mysql.connection.cursor()
    cur.execute("INSERT INTO tasks (name, status, deadline, event_id, attendee_id) VALUES (%s, %s, %s, %s, %s)",
                (name, status, deadline, event_id, attendee_id))
    mysql.connection.commit()
    cur.close()
    return jsonify({"message": "Task created successfully"}), 201

@app.route('/api/tasks/<int:id>', methods=['PUT'])
def update_task(id):
    data = request.get_json()
    name = data['name']
    status = data['status']
    deadline = data['deadline']
    cur = mysql.connection.cursor()
    cur.execute("UPDATE tasks SET name=%s, status=%s, deadline=%s WHERE id=%s",
                (name, status, deadline, id))
    mysql.connection.commit()
    cur.close()
    return jsonify({"message": "Task updated successfully"}), 200

@app.route('/api/tasks/<int:id>', methods=['DELETE'])
def delete_task(id):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM tasks WHERE id=%s", (id,))
    mysql.connection.commit()
    cur.close()
    return jsonify({"message": "Task deleted successfully"}), 200

if __name__ == '__main__':
    app.run(debug=True)
